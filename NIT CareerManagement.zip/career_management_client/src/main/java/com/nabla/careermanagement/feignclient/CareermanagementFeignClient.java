package com.nabla.careermanagement.feignclient;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nabla.careermanagement.model.CareerManagementApiResponse;
import com.nabla.careermanagement.model.JobDetails;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
@FeignClient(name ="career-management")
public interface CareermanagementFeignClient {
	@RequestMapping(value = "/jobDetails", produces = { "application/json" }, consumes = {
	"application/json" }, method = RequestMethod.POST)
CareerManagementApiResponse addNewjobDetails(
	@Parameter(in = ParameterIn.DEFAULT, description = "paas all required field into request body.", required = true, schema = @Schema()) @Valid @RequestBody JobDetails jobDetails);

	
	@RequestMapping(value = "/jobDetails", produces = { "application/json" }, method = RequestMethod.GET)
	CareerManagementApiResponse getAllJobDetails(
			@Parameter(in = ParameterIn.QUERY, description = "Offset of the result", schema = @Schema()) @Valid @RequestParam(value = "offset", required = false) Integer offset,
			@Parameter(in = ParameterIn.QUERY, description = "Limit of the result", schema = @Schema()) @Valid @RequestParam(value = "limit", required = false) Integer limit);

	
	@RequestMapping(value = "/jobDetails/{jobId}", produces = { "application/json" }, method = RequestMethod.DELETE)
	CareerManagementApiResponse deleteJobDetails(
			@Parameter(in = ParameterIn.PATH, description = "Unique id for identifying previous and current job details", required = true, schema = @Schema()) @PathVariable("jobId") Integer jobId);

	@RequestMapping(value = "/jobDetails/{jobId}", produces = { "application/json" }, consumes = {
	"application/json" }, method = RequestMethod.PUT)
CareerManagementApiResponse updateExistingJobDetails(
	@Parameter(in = ParameterIn.PATH, description = "Unique id for identifying previous and current job details", required = false, schema = @Schema()) @PathVariable("jobId") Integer jobId,
	@Parameter(in = ParameterIn.DEFAULT, description = "", schema = @Schema()) @RequestBody JobDetails body);

	@RequestMapping(value = "/jobDetails/{jobId}", produces = { "application/json" }, method = RequestMethod.GET)
	CareerManagementApiResponse getAllJobDetails(
			@Parameter(in = ParameterIn.PATH, description = "Unique id for identifying previous and current job details", required = true, schema = @Schema()) @PathVariable("jobId") Integer jobId);
}
