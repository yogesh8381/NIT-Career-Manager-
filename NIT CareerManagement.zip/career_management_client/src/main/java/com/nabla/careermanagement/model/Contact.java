package com.nabla.careermanagement.model;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.springframework.validation.annotation.Validated;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Contact
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T08:35:19.157Z[GMT]")

@Entity
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer contactId;
	@JsonProperty("name")
	private String name;

	@JsonProperty("email")
	private String email;

	@JsonProperty("contactNumber")
	private String contactNumber;

	@JsonProperty("position")
	private String position;

	public Contact name(String name) {
		this.name = name;
		return this;
	}

	/**
	 * contact person name
	 * 
	 * @return name
	 **/
	@Schema(example = "Abha Bansal", description = "contact person name")

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Contact email(String email) {
		this.email = email;
		return this;
	}

	/**
	 * contact person email
	 * 
	 * @return email
	 **/
	@Schema(example = "abha.bansal@nablainfotech.com", description = "contact person email")

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Contact contactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
		return this;
	}

	/**
	 * contact person phone number
	 * 
	 * @return contactNumber
	 **/
	@Schema(example = "7894561230", description = "contact person phone number")

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Contact position(String position) {
		this.position = position;
		return this;
	}

	/**
	 * contact person position
	 * 
	 * @return position
	 **/
	@Schema(example = "HR", description = "contact person position")

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Contact contact = (Contact) o;
		return Objects.equals(this.name, contact.name) && Objects.equals(this.email, contact.email)
				&& Objects.equals(this.contactNumber, contact.contactNumber)
				&& Objects.equals(this.position, contact.position);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, email, contactNumber, position);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Contact {\n");

		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    email: ").append(toIndentedString(email)).append("\n");
		sb.append("    contactNumber: ").append(toIndentedString(contactNumber)).append("\n");
		sb.append("    position: ").append(toIndentedString(position)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
