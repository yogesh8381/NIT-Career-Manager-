package com.nabla.careermanagement.model;

import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * JobDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T08:35:19.157Z[GMT]")

@Entity
public class JobDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonProperty("jobId")
	private Integer jobId;
	@Size(min = 2, message = "jobProfile should have atleast 2 character")
	@JsonProperty("jobProfile")
	private String jobProfile;

	public String getJobProfile() {
		return jobProfile;
	}

	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}

	@JsonProperty("numberOfOpenings")
	private Integer numberOfOpenings;

	@JsonProperty("jobLocation")
	private String jobLocation;

	@JsonProperty("ctc")
	private String ctc;

	@JsonProperty("jobDescription")
	private String jobDescription;

	@JsonProperty("skillsRequired")
	private String skillsRequired;

	@OneToOne(cascade = CascadeType.ALL)
	@JsonProperty("eligibilityCriteria")
	private EligibilityCriteria eligibilityCriteria;
	@OneToOne(cascade = CascadeType.ALL)
	@JsonProperty("contact")
	private Contact contact;

	@JsonProperty("applyLink")
	private String applyLink;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonProperty("lastDate")
	private String lastDate;

	@JsonProperty("createdDate")
	private String createdDate;

	@JsonProperty("modifiedDate")
	private String modifiedDate;

	@JsonProperty("modifiedBy")
	private String modifiedBy;

	@JsonProperty("createdBy")
	private String createdBy;

	public JobDetails numberOfOpenings(Integer numberOfOpenings) {
		this.numberOfOpenings = numberOfOpenings;
		return this;
	}

	/**
	 * enter number of opening available
	 * 
	 * @return numberOfOpenings
	 **/
	@Schema(example = "2", description = "enter number of opening available")

	public Integer getNumberOfOpenings() {
		return numberOfOpenings;
	}

	public void setNumberOfOpenings(Integer numberOfOpenings) {
		this.numberOfOpenings = numberOfOpenings;
	}

	public JobDetails jobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
		return this;
	}

	public Integer getJobId() {
		return jobId;
	}

	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}

	/**
	 * enter job location
	 * 
	 * @return jobLocation
	 **/
	@Schema(example = "pune", description = "enter job location")

	public String getJobLocation() {
		return jobLocation;
	}

	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}

	/**
	 * add current year
	 * 
	 * @return CTC
	 **/
	@Schema(example = "6 to 12 LPA", description = "add current year")

	public String getctc() {
		return ctc;
	}

	public void setctc(String ctc) {
		this.ctc = ctc;
	}

	public JobDetails jobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
		return this;
	}

	/**
	 * add job description here
	 * 
	 * @return jobDescription
	 **/
	@Schema(example = "We are looking for seniour Java Developer", description = "add job description here")

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public JobDetails skillsRequired(String skillsRequired) {
		this.skillsRequired = skillsRequired;
		return this;
	}

	/**
	 * add skillSet here
	 * 
	 * @return skillsRequired
	 **/
	@Schema(example = "core java, Spring, hibernate", description = "add  skillset here")

	public String getSkillsRequired() {
		return skillsRequired;
	}

	public void setSkillsRequired(String skillsRequired) {
		this.skillsRequired = skillsRequired;
	}

	public JobDetails eligibilityCriteria(EligibilityCriteria eligibilityCriteria) {
		this.eligibilityCriteria = eligibilityCriteria;
		return this;
	}

	/**
	 * Get eligibilityCriteria
	 * 
	 * @return eligibilityCriteria
	 **/
	@Schema(description = "")

	@Valid
	public EligibilityCriteria getEligibilityCriteria() {
		return eligibilityCriteria;
	}

	public void setEligibilityCriteria(EligibilityCriteria eligibilityCriteria) {
		this.eligibilityCriteria = eligibilityCriteria;
	}

	public JobDetails contact(Contact contact) {
		this.contact = contact;
		return this;
	}

	/**
	 * Get contact
	 * 
	 * @return contact
	 **/
	@Schema(description = "")

	@Valid
	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public JobDetails applyLink(String applyLink) {
		this.applyLink = applyLink;
		return this;
	}

	/**
	 * Get applyLink
	 * 
	 * @return applyLink
	 **/
	@Schema(example = "https://nablainfotech.com/carreer/apply", description = "")

	public String getApplyLink() {
		return applyLink;
	}

	public void setApplyLink(String applyLink) {
		this.applyLink = applyLink;
	}

	public JobDetails lastDate(String lastDate) {
		this.lastDate = lastDate;
		return this;
	}

	/**
	 * Get lastDate
	 * 
	 * @return lastDate
	 **/
	@Schema(description = "")
//	@JsonSerialize(using = CustomJsonDateSerializer.class)
	public String getLastDate() {
		return lastDate;
	}

	public void setLastDate(String lastDate) {
		this.lastDate = lastDate;
	}

	public JobDetails createdDate(String createdDate) {
		this.createdDate = createdDate;
		return this;
	}

	/**
	 * Get createdDate
	 * 
	 * @return createdDate
	 **/
	@Schema(description = "")

	@Valid
	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public JobDetails modifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
		return this;
	}

	/**
	 * Get modifiedDate
	 * 
	 * @return modifiedDate
	 **/
	@Schema(description = "")

	@Valid
	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public JobDetails modifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
		return this;
	}

	/**
	 * Get modifiedBy
	 * 
	 * @return modifiedBy
	 **/
	@Schema(description = "")

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public JobDetails createdBy(String createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	/**
	 * Get createdBy
	 * 
	 * @return createdBy
	 **/
	@Schema(description = "")

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		JobDetails jobDetails = (JobDetails) o;
		return Objects.equals(this.jobProfile, jobDetails.jobProfile)
				&& Objects.equals(this.numberOfOpenings, jobDetails.numberOfOpenings)
				&& Objects.equals(this.jobLocation, jobDetails.jobLocation) && Objects.equals(this.ctc, jobDetails.ctc)
				&& Objects.equals(this.jobDescription, jobDetails.jobDescription)
				&& Objects.equals(this.skillsRequired, jobDetails.skillsRequired)
				&& Objects.equals(this.eligibilityCriteria, jobDetails.eligibilityCriteria)
				&& Objects.equals(this.contact, jobDetails.contact)
				&& Objects.equals(this.applyLink, jobDetails.applyLink)
				&& Objects.equals(this.lastDate, jobDetails.lastDate)
				&& Objects.equals(this.createdDate, jobDetails.createdDate)
				&& Objects.equals(this.modifiedDate, jobDetails.modifiedDate)
				&& Objects.equals(this.modifiedBy, jobDetails.modifiedBy)
				&& Objects.equals(this.createdBy, jobDetails.createdBy);
	}

	@Override
	public int hashCode() {
		return Objects.hash(jobProfile, numberOfOpenings, jobLocation, ctc, jobDescription, skillsRequired,
				eligibilityCriteria, contact, applyLink, lastDate, createdDate, modifiedDate, modifiedBy, createdBy);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class JobDetails {\n");

		sb.append("    jobProfile: ").append(toIndentedString(jobProfile)).append("\n");
		sb.append("    numberOfOpenings: ").append(toIndentedString(numberOfOpenings)).append("\n");
		sb.append("    jobLocation: ").append(toIndentedString(jobLocation)).append("\n");
		sb.append("    ctc: ").append(toIndentedString(ctc)).append("\n");
		sb.append("    jobDescription: ").append(toIndentedString(jobDescription)).append("\n");
		sb.append("    skillsRequired: ").append(toIndentedString(skillsRequired)).append("\n");
		sb.append("    eligibilityCriteria: ").append(toIndentedString(eligibilityCriteria)).append("\n");
		sb.append("    contact: ").append(toIndentedString(contact)).append("\n");
		sb.append("    applyLink: ").append(toIndentedString(applyLink)).append("\n");
		sb.append("    lastDate: ").append(toIndentedString(lastDate)).append("\n");
		sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
		sb.append("    modifiedDate: ").append(toIndentedString(modifiedDate)).append("\n");
		sb.append("    modifiedBy: ").append(toIndentedString(modifiedBy)).append("\n");
		sb.append("    createdBy: ").append(toIndentedString(createdBy)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
