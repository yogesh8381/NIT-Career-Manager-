package com.nabla.careermanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.nabla.careermanagement.feignclient.CareermanagementFeignClient;
import com.nabla.careermanagement.model.CareerManagementApiResponse;
import com.nabla.careermanagement.model.Contact;
import com.nabla.careermanagement.model.EligibilityCriteria;
import com.nabla.careermanagement.model.JobDetails;

@Controller
public class MainController {

	@Autowired
	public CareermanagementFeignClient careermanagementFeignClient;
	
	@GetMapping("/")
public String init() {
		System.out.println("hello mvc");
	return "index";
}
	
	

	
//	@RequestMapping(value = "/addNewJob", method = RequestMethod.POST)
@SuppressWarnings("unchecked")
	//    public String addjobDetails(@ModelAttribute JobDetails jobDetails) throws Exception {
//        System.out.println("start");
//        
//        careermanagementFeignClient.addNewjobDetails(jobDetails);
//       
//    return "index";    }

	  @RequestMapping(value="/login", method = RequestMethod.GET)
	public String home(Model model) {
		CareerManagementApiResponse jobOpening = careermanagementFeignClient.getAllJobDetails(0, 1);
		List<JobDetails> results = jobOpening.getResults();
		List<JobDetails> addJobOpeningDetails = new ArrayList<>();
		for(JobDetails jobdetails : results)
		{
			addJobOpeningDetails.add(jobdetails);
			
			//System.out.println(addJobOpeningDetails);
		}
		model.addAttribute("jobOpeningDetailsList", addJobOpeningDetails);
		
		return "index";
	}

@RequestMapping("/delete/{jobId}")
public RedirectView deleteUser(@PathVariable("jobId") Integer jobId, HttpServletRequest request) {
	careermanagementFeignClient.deleteJobDetails(jobId);
	RedirectView redirectView = new RedirectView();
	redirectView.setUrl(request.getContextPath() + "/login");
	return redirectView;
}
  
   @PostMapping("/createNewJob")
	public RedirectView createNewJobOpeninhg(@ModelAttribute JobDetails jobDetails,@ModelAttribute EligibilityCriteria eligibilityCriteria, @ModelAttribute Contact contact,HttpServletRequest request, Model model) {
       // System.out.println(jobDetails);
        //System.out.println(contact);
        JobDetails jobDetailsRequestBody = new JobDetails();
        jobDetailsRequestBody.setJobProfile(jobDetails.getJobProfile());
        jobDetailsRequestBody.numberOfOpenings(jobDetails.getNumberOfOpenings());
        jobDetailsRequestBody.jobLocation(jobDetails.getJobLocation());
        jobDetailsRequestBody.setctc(jobDetails.getctc());
        jobDetailsRequestBody.setJobDescription(jobDetails.getJobDescription());
        jobDetailsRequestBody.setSkillsRequired(jobDetails.getSkillsRequired());
        jobDetailsRequestBody.setEligibilityCriteria(eligibilityCriteria);
        jobDetailsRequestBody.setContact(contact);
        jobDetailsRequestBody.setApplyLink(jobDetails.getApplyLink());
        jobDetailsRequestBody.setLastDate(jobDetails.getLastDate());
        jobDetailsRequestBody.setCreatedDate(jobDetails.getCreatedDate());
        jobDetailsRequestBody.setModifiedDate(jobDetails.getModifiedDate());
        jobDetailsRequestBody.setModifiedBy(jobDetails.getModifiedBy());
        jobDetailsRequestBody.setCreatedBy(jobDetails.getCreatedBy());
        System.out.println(jobDetailsRequestBody);
        CareerManagementApiResponse jobDetailsNew = careermanagementFeignClient.addNewjobDetails(jobDetailsRequestBody);
		//List<JobDetails> results = addNewJobOpeningDetails.getResults();
		System.out.println(jobDetailsNew );
		//model.addAttribute("Message", jobDetails.getJobId() + " Succefully Registered");
		//System.out.println(jobDetails.getJobId());
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath() + "/");
		return redirectView;
}
	@RequestMapping("/update/{jobId}")
	public String getJobOpening(@PathVariable("jobId") Integer jobId, HttpServletRequest request,
			Model model) {
		CareerManagementApiResponse getJobOpeningDetails = careermanagementFeignClient.getAllJobDetails(jobId);
		List<JobDetails> results = getJobOpeningDetails.getResults();
		JobDetails jobOpeningDetails = new JobDetails();
		for(JobDetails jobOpening : results)
		{
			jobOpeningDetails = jobOpening;
			
			//System.out.println(addJobOpeningDetails);
		}
		model.addAttribute("job", jobOpeningDetails);
		
		
		return "UpdateForm";
	}
	@RequestMapping(value="/updateJobOpening/{jobId}", method = RequestMethod.POST)
	public RedirectView updateProject(@PathVariable("jobId") Integer jobId,@ModelAttribute JobDetails jobDetails,@ModelAttribute EligibilityCriteria eligibilityCriteria, @ModelAttribute Contact contact,HttpServletRequest request)
	{
		 JobDetails jobDetailsRequestBody = new JobDetails();
		 jobDetailsRequestBody.setJobId(jobDetails.getJobId());
	        jobDetailsRequestBody.setJobProfile(jobDetails.getJobProfile());
	        jobDetailsRequestBody.numberOfOpenings(jobDetails.getNumberOfOpenings());
	        jobDetailsRequestBody.jobLocation(jobDetails.getJobLocation());
	        jobDetailsRequestBody.setctc(jobDetails.getctc());
	        jobDetailsRequestBody.setJobDescription(jobDetails.getJobDescription());
	        jobDetailsRequestBody.setSkillsRequired(jobDetails.getSkillsRequired());
	        jobDetailsRequestBody.setEligibilityCriteria(eligibilityCriteria);
	        jobDetailsRequestBody.setContact(contact);
	        jobDetailsRequestBody.setApplyLink(jobDetails.getApplyLink());
	        jobDetailsRequestBody.setLastDate(jobDetails.getLastDate());
	        jobDetailsRequestBody.setCreatedDate(jobDetails.getCreatedDate());
	        jobDetailsRequestBody.setModifiedDate(jobDetails.getModifiedDate());
	        jobDetailsRequestBody.setModifiedBy(jobDetails.getModifiedBy());
	        jobDetailsRequestBody.setCreatedBy(jobDetails.getCreatedBy());
	        System.out.println(jobDetailsRequestBody);
		 careermanagementFeignClient.updateExistingJobDetails(jobDetails.getJobId(), jobDetailsRequestBody);
		
		
		
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath() + "/login");
		return redirectView;
		
	}



}
		

	
	
	


