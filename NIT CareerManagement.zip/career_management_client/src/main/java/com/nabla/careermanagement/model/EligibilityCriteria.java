package com.nabla.careermanagement.model;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * EligibilityCriteria
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T08:35:19.157Z[GMT]")

@Entity
public class EligibilityCriteria {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer eligibilityCriteriaId;
	@JsonProperty("qualification")
	private String qualification;

	@JsonProperty("experience")
	private String experience;

	@JsonProperty("noticePeriod")
	private String noticePeriod;

	@JsonProperty("passoutYear")
	private Integer passoutYear;

	@JsonProperty("branch")
	private String branch;

	public EligibilityCriteria qualification(String qualification) {
		this.qualification = qualification;
		return this;
	}

	/**
	 * Add your qualification here
	 * 
	 * @return qualification
	 **/
	@Schema(example = "BE/BTECH", description = "Add your qualification here")

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public EligibilityCriteria experience(String experience) {
		this.experience = experience;
		return this;
	}

	/**
	 * add experience
	 * 
	 * @return experience
	 **/
	@Schema(example = "3 - 7 Years", description = "add experience")

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public EligibilityCriteria noticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
		return this;
	}

	/**
	 * add information related to notice period
	 * 
	 * @return noticePeriod
	 **/
	@Schema(example = "immediate/ Max 15 Days", description = "add information related to notice period")

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public EligibilityCriteria passoutYear(Integer passoutYear) {
		this.passoutYear = passoutYear;
		return this;
	}

	/**
	 * enter passout year
	 * 
	 * @return passoutYear
	 **/
	@Schema(example = "2019", description = "enter passout year")

	public Integer getPassoutYear() {
		return passoutYear;
	}

	public void setPassoutYear(Integer passoutYear) {
		this.passoutYear = passoutYear;
	}

	public EligibilityCriteria branch(String branch) {
		this.branch = branch;
		return this;
	}

	/**
	 * add graduation branch here
	 * 
	 * @return branch
	 **/
	@Schema(example = "IT/Computer/E&TC/MCA", description = "add graduation branch here")

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		EligibilityCriteria eligibilityCriteria = (EligibilityCriteria) o;
		return Objects.equals(this.qualification, eligibilityCriteria.qualification)
				&& Objects.equals(this.experience, eligibilityCriteria.experience)
				&& Objects.equals(this.noticePeriod, eligibilityCriteria.noticePeriod)
				&& Objects.equals(this.passoutYear, eligibilityCriteria.passoutYear)
				&& Objects.equals(this.branch, eligibilityCriteria.branch);
	}

	@Override
	public int hashCode() {
		return Objects.hash(qualification, experience, noticePeriod, passoutYear, branch);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class EligibilityCriteria {\n");

		sb.append("    qualification: ").append(toIndentedString(qualification)).append("\n");
		sb.append("    experience: ").append(toIndentedString(experience)).append("\n");
		sb.append("    noticePeriod: ").append(toIndentedString(noticePeriod)).append("\n");
		sb.append("    passoutYear: ").append(toIndentedString(passoutYear)).append("\n");
		sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
