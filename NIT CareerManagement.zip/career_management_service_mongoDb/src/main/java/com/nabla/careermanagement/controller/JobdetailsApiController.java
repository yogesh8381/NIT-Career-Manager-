/**
 * controller class
 * 
 */

package com.nabla.careermanagement.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.nabla.careermanagement.exception.ResourceNotFoundException;
import com.nabla.careermanagement.model.CareerManagementApiResponse;
import com.nabla.careermanagement.model.JobDetails;
import com.nabla.careermanagement.service.CareerManagementService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 
 * @author yogesh
 *
 */
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-03-25T08:35:19.157Z[GMT]")
@RestController
public class JobdetailsApiController implements JobdetailsApi {

	@Autowired
	private CareerManagementService careerManagementService;

	private static final Logger log = LoggerFactory.getLogger(JobdetailsApiController.class);

	private final HttpServletRequest request;

	@org.springframework.beans.factory.annotation.Autowired
	public JobdetailsApiController(HttpServletRequest request) {

		this.request = request;
	}

	/**
	 * this method is used for create new jobOpening into database 
	 * @param jobDetails
	 * @exception ResourceNotFoundException
	 * @return jobDetails
	 * 
	 * 
	 */
	public ResponseEntity<CareerManagementApiResponse> addNewjobDetails(
			@Parameter(in = ParameterIn.DEFAULT, description = "paas all required field into request body.", required = true, schema = @Schema()) @Valid @RequestBody JobDetails jobDetails) {

		if (jobDetails.getJobDescription().equals("")
				|| jobDetails.getNumberOfOpenings().equals("") || jobDetails.getContact().equals("")
				|| jobDetails.getEligibilityCriteria().equals("") || jobDetails.getJobDescription().equals("")
				|| jobDetails.getJobLocation().equals("")) {
			throw new ResourceNotFoundException("The required field in request body is empty");
		} else {
			try {
				CareerManagementApiResponse careerManagementApiResponse = careerManagementService
						.addNewJobDetails(jobDetails);
				return new ResponseEntity<>(careerManagementApiResponse, HttpStatus.CREATED);
			} catch (Exception e) {
				log.error("Couldn't serialize response for content type application/json", e);
				throw new ResourceNotFoundException("Please check url or enter required field");
			}
		}
	}

	/**
	 * this method is used for delete  existing jobOpening entry from database by calling careerManagementService
	 * class 
	 * @param jobId
	 * @exception ResourceNotFoundException
	 * 
	 * 
	 */
	public ResponseEntity<CareerManagementApiResponse> deleteJobDetails(Integer jobId) {
		String accept = request.getHeader("Accept");
		if (accept != null && accept.contains("application/json")) {
			try {
				CareerManagementApiResponse careerManagementApiResponse = careerManagementService
						.deletejobDetails(jobId);
				return new ResponseEntity<>(careerManagementApiResponse, HttpStatus.OK);
			} catch (Exception e) {
				log.error("Couldn't serialize response for content type application/json", e);
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}
		throw new ResourceNotFoundException("jobdetails  with this id " + jobId + "  not available into Database");

	}

	/**
	 * this method is used for get all current jobOpening from database
	 * 
	 * @param offset
	 * @param limit
	 * @exception ResourceNotFoundException
	 * @return jobOpening
	 * 
	 */

	public ResponseEntity<CareerManagementApiResponse> getAllJobDetails(
			@Parameter(in = ParameterIn.QUERY, description = "Offset of the result", schema = @Schema()) @Valid @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
			@Parameter(in = ParameterIn.QUERY, description = "Limit of the result", schema = @Schema()) @Valid @RequestParam(value = "limit", required = false) Integer limit) {

		try {
			CareerManagementApiResponse careerManagementApiResponse = careerManagementService.getAllJobDetails(offset,
					limit);

			return new ResponseEntity<>(careerManagementApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Couldn't serialize response for content type application/json", e);
			throw new ResourceNotFoundException("Please check enter url is correct or not  ");
		}
	}

	/**
	 * this method is used for Specific jobOpening from database by calling
	 * careerManagementService class
	 * @param jobId
	 * @exception ResourceNotFoundException
	 * @return jobDetails
	 */

	public ResponseEntity<CareerManagementApiResponse> getAllJobDetails(Integer jobId) {
		String accept = request.getHeader("Accept");
		if (accept != null && accept.contains("application/json")) {

			try {

				CareerManagementApiResponse careerManagementApiResponse = careerManagementService
						.getjobOpeningById(jobId);

				return new ResponseEntity<>(careerManagementApiResponse, HttpStatus.OK);
			} catch (Exception e) {

				log.error("Couldn't serialize response for content type application/json", e);

			}
		}
		throw new ResourceNotFoundException("jobdetails  with this id " + jobId + "  not available into Database");
	}

	/**
	 *this method is used for update specific existing jobOpening
	 * @param body
	 * @param jobId
	 * @exception ResourceNotFoundException
	 * @return jobDetails
	 */
	public ResponseEntity<CareerManagementApiResponse> updateJobDetailsSpecificField(
			@Parameter(in = ParameterIn.PATH, description = "Unique id for identifying previous and current job details", required = true, schema = @Schema()) @PathVariable("jobId") Integer jobId,
			@Parameter(in = ParameterIn.DEFAULT, description = "", schema = @Schema()) @RequestBody JobDetails body) {
		try {
			CareerManagementApiResponse careerManagementApiResponse = careerManagementService
					.updateJobDetailsSpecificField(jobId, body);

			return new ResponseEntity<>(careerManagementApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Couldn't serialize response for content type application/json", e);
			throw new ResourceNotFoundException("Please check information enter correctly or not");
		}
	}

	/**
	 * this method is used for update existing jobOpening record
	 * @param jobId
	 * @param jobdetails
	 * @throws ResourceNotFoundException
	 * @return jobDetails
	 */

	@Override
	public ResponseEntity<CareerManagementApiResponse> updateExistingJobDetails(
			@Parameter(in = ParameterIn.PATH, description = "Unique id for identifying previous and current job details", required = true, schema = @Schema()) @PathVariable("jobId") Integer jobId,
			@Parameter(in = ParameterIn.DEFAULT, description = "", schema = @Schema()) @RequestBody JobDetails jobdetails) {
		if (jobdetails.getJobDescription().equals("") || jobdetails.getNumberOfOpenings().equals("")
				|| jobdetails.getContact().equals("") || jobdetails.getSkillsRequired().equals("")
				|| jobdetails.getJobDescription().equals("") || jobdetails.getJobLocation().equals("")) {
			throw new ResourceNotFoundException("The required field in request body is empty");
		} else {
			try {
				CareerManagementApiResponse careerManagementApiResponse = careerManagementService
						.updateJobDetails(jobId, jobdetails);
				return new ResponseEntity<>(careerManagementApiResponse, HttpStatus.OK);
			} catch (Exception e) {
				log.error("Couldn't serialize response for content type application/json", e);
				throw new ResourceNotFoundException(" enter required field or this" + " " + jobdetails.getJobId() + " "
						+ "related data not available please provide valid id");
			}
		}
	}

}
