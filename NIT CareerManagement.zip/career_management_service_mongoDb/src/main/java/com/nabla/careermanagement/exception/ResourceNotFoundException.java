package com.nabla.careermanagement.exception;

/**
 * 
 * @author Yogesh
 *
 */
public class ResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
/**
 * 
 * @param message
 */
	public ResourceNotFoundException(String message) {
		super(message);
	}
}