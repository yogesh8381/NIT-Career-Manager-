package com.nabla.careermanagement.service.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.nabla.careermanagement.exception.ResourceNotFoundException;
import com.nabla.careermanagement.model.CareerManagementApiResponse;
import com.nabla.careermanagement.model.JobDetails;
import com.nabla.careermanagement.model.OffsetBasedPageRequest;
import com.nabla.careermanagement.model.Pagination;
import com.nabla.careermanagement.repository.CareerRepository;
import com.nabla.careermanagement.service.CareerManagementService;

/**
 * 
 * @author Yogesh
 *
 */
@Service
public class CareerManagementServiceImpl implements CareerManagementService {

	@Autowired
	private CareerRepository careerRepository;
	private static final Logger log = LoggerFactory.getLogger(CareerManagementServiceImpl.class);

	/**
	 * 
	 * This method represent adding or creating new jobOpening entry into database
	 *@param careerManagementField
	 *@throws ResourceNotFoundException
	 *@return jobOpening
	 */
	@Override
	public CareerManagementApiResponse addNewJobDetails(JobDetails jobOpening) {
		CareerManagementApiResponse careerManagementApiResponse = new CareerManagementApiResponse();

		try {
			JobDetails saveJobDetails = careerRepository.save(jobOpening);
			log.info("save data into database");
			List<JobDetails> results = new ArrayList<>();
			results.add(saveJobDetails);
			careerManagementApiResponse.setResults(results);
			List<String> messages = new ArrayList<>();
			messages.add(" New Jodetails entry added successfully into database");
			Pagination pagination = new Pagination();
			pagination.setLimit(1);
			pagination.setOffset(0);
			pagination.setTotal(1);
			careerManagementApiResponse.setPagination(pagination);
			careerManagementApiResponse.setMessages(messages);
			careerManagementApiResponse.setStatusCode(201);
			careerManagementApiResponse.setStatusMessage("CREATED");

		} catch (Exception e) {
			log.error("Couldn't process this request enter valid request");
			throw new ResourceNotFoundException("please enter valid or required inormation");
		}

		return careerManagementApiResponse;

	}

	/**
	 * 
	 *this method represent delete existing jobOpening entry from database
	 *@param jobId
	 *@exception ResourceNotFoundException
	 */

	@Override
	public CareerManagementApiResponse deletejobDetails(int jobId) {
		Optional<JobDetails> checkjobavailability = this.careerRepository.findById(jobId);
		log.info("check data available or not into database");
		CareerManagementApiResponse careerManagementApiResponse = new CareerManagementApiResponse();
		if (checkjobavailability.isPresent()) {

			try {
				careerRepository.delete(checkjobavailability.get());
				
				List<String> messages = new ArrayList<>();
				messages.add("record deleted from database");
				careerManagementApiResponse.setMessages(messages);
				Pagination pagination = new Pagination();
				pagination.setLimit(1);
				pagination.setOffset(0);
				pagination.setTotal(1);
				careerManagementApiResponse.setPagination(pagination);
				careerManagementApiResponse.setStatusCode(200);
				careerManagementApiResponse.setStatusMessage("OK");

			} catch (Exception e) {
				throw new ResourceNotFoundException("jobdetails  with this " + jobId + " not available in Database");

			}

		} else {
			log.error("Couldn't process this request enter valid jobid");
			throw new ResourceNotFoundException("jobdetails  with this "+ jobId + "not available into Database");

		}

		return careerManagementApiResponse;
	}

	/**
	 *This method represent  fetch joOpening from database using jobId
	 * @param jobId
	 * @exception ResourceNotFoundException
	 * @return jobOpening
	 * 
	 */
	@Override
	public CareerManagementApiResponse getjobOpeningById(int jobId) {
		Optional<JobDetails> checkjobdetailsAvailability = this.careerRepository.findById(jobId);
		CareerManagementApiResponse careerManagementApiResponse = new CareerManagementApiResponse();
		log.info("fetch data from database");
		if (checkjobdetailsAvailability.isPresent()) {

			try {
				JobDetails carrerManagementDetails = checkjobdetailsAvailability.get();
				List<JobDetails> results = new ArrayList<>();
				results.add(carrerManagementDetails);
				careerManagementApiResponse.setResults(results);
				List<String> messages = new ArrayList<>();
				messages.add("loading this record from database");
				careerManagementApiResponse.setMessages(messages);
				Pagination pagination = new Pagination();
				pagination.setLimit(1);
				pagination.setOffset(0);
				pagination.setTotal(1);

				careerManagementApiResponse.setPagination(pagination);
				careerManagementApiResponse.setStatusCode(200);
				careerManagementApiResponse.setStatusMessage("OK");

			} catch (Exception e) {
				throw new ResourceNotFoundException("jobdetails with this " + jobId + " not available in Database");

			}

		} else {
			log.error("Couldn't process this request enter valid jobid");
			throw new ResourceNotFoundException("jobdetails  with this" + jobId + " not available in Database");

		}

		return careerManagementApiResponse;
	}

	/**
	 * 
	 * this method  represent return all jobDetails from database or using pagination fetch limited records
	 * record
	 * @param offset
	 * @param limit
	 * @exception ResourceNotFoundException
	 * @return jobOpening
	 */

	@Override
	public CareerManagementApiResponse getAllJobDetails(@Valid Integer offset, @Valid Integer limit) {
		CareerManagementApiResponse careerManagementApiResponse = new CareerManagementApiResponse();

		log.debug("Get all jobdetails with limit {} and offset {}", limit, offset);
		Pageable pageable = new OffsetBasedPageRequest(offset, limit);
		try {

			List<JobDetails> fetchAllJobDetails = careerRepository.findAll(pageable).getContent();
			int totalSize = careerRepository.findAll().size();
			List<JobDetails> results = new ArrayList<>();
			for (JobDetails list1 : fetchAllJobDetails) {
				results.add(list1);
			}
			List<String> messages = new ArrayList<>();
			messages.add(" fetch all details from database");
			careerManagementApiResponse.setResults(results);
			Pagination pagination = new Pagination();
			pagination.setLimit(limit);
			pagination.setOffset(offset);
			pagination.setTotal(totalSize);
			careerManagementApiResponse.setPagination(pagination);
			careerManagementApiResponse.setMessages(messages);
			careerManagementApiResponse.setStatusCode(200);
			careerManagementApiResponse.setStatusMessage("OK");

		} catch (Exception e) {
			log.error("Couldn't process this request check url", e);

		}
		return careerManagementApiResponse;
	}

	/**
	 * 
	 * This method represent update existing jobOpening from database
	 * @param jobId
	 * @param jobDetails
	 * @return updated jobOpening
	 */
	@Override
	public CareerManagementApiResponse updateJobDetails(Integer jobId, JobDetails jobDetails) {
		Optional<JobDetails> checkjobdetails = this.careerRepository.findById(jobId);
		log.info("update existing record from database");
		CareerManagementApiResponse careerManagementApiResponse = new CareerManagementApiResponse();

		if (checkjobdetails.isPresent()) {
			JobDetails updateJobDetails = checkjobdetails.get();
			updateJobDetails.setJobId(jobDetails.getJobId());
			updateJobDetails.setJobProfile(jobDetails.getJobProfile());
			updateJobDetails.setJobLocation(jobDetails.getJobLocation());
			updateJobDetails.setctc(jobDetails.getctc());
			updateJobDetails.setJobDescription(jobDetails.getJobDescription());
			updateJobDetails.setSkillsRequired(jobDetails.getSkillsRequired());
			updateJobDetails.setEligibilityCriteria(jobDetails.getEligibilityCriteria());
			updateJobDetails.setContact(jobDetails.getContact());
			updateJobDetails.setApplyLink(jobDetails.getApplyLink());
			updateJobDetails.setLastDate(jobDetails.getLastDate());
			updateJobDetails.setCreatedDate(jobDetails.getCreatedDate());
			updateJobDetails.setModifiedDate(jobDetails.getModifiedDate());
			updateJobDetails.setModifiedBy(jobDetails.getModifiedBy());
			updateJobDetails.setCreatedBy(jobDetails.getCreatedBy());

			try {
				JobDetails carrerManagemnetUpdateDetails = careerRepository.save(updateJobDetails);
				List<JobDetails> results = new ArrayList<>();
				results.add(carrerManagemnetUpdateDetails);
				careerManagementApiResponse.setResults(results);
				List<String> messages = new ArrayList<>();
				messages.add(" jobdetails update successfully");
				Pagination pagination = new Pagination();
				pagination.setLimit(1);
				pagination.setOffset(0);
				pagination.setTotal(1);
				careerManagementApiResponse.setPagination(pagination);
				careerManagementApiResponse.setMessages(messages);
				careerManagementApiResponse.setStatusCode(200);
				careerManagementApiResponse.setStatusMessage("OK");

			} catch (Exception e) {
				log.error("Couldn't process this request enter valid jobid");

			}

		} else {
			log.error("Couldn't process this request enter valid jobid");
			throw new ResourceNotFoundException(
					"jobdetails  with this " + jobDetails.getJobId() + "  not available in Database");

		}
		return careerManagementApiResponse;
	}
	
	/**
	 * 
	 *  This method represent update single field of jobOpening no need to send whole request body
	 * @param jobId
	 * @param jobDetails
	 * @return updated JobOpening
	 */

	@Override
	public CareerManagementApiResponse updateJobDetailsSpecificField(Integer jobId, JobDetails jobDetails) {
		Optional<JobDetails> checkjobdetailsAvailability = this.careerRepository.findById(jobId);
		CareerManagementApiResponse careerManagementApiResponse = new CareerManagementApiResponse();
		if (checkjobdetailsAvailability.isPresent()) {
			JobDetails updateJobDetails = checkjobdetailsAvailability.get();
			log.info("update specific jobdetails", updateJobDetails);
			updateJobDetails.setJobId(jobDetails.getJobId());
			if (jobDetails.getJobProfile() != null) {
				updateJobDetails.setJobProfile(jobDetails.getJobProfile());

			} else {
				updateJobDetails.setJobProfile(updateJobDetails.getJobProfile());
			}

			if (jobDetails.getJobLocation() != null) {
				updateJobDetails.setJobLocation(jobDetails.getJobLocation());

			} else {
				updateJobDetails.setJobLocation(updateJobDetails.getJobLocation());
			}
			if (jobDetails.getctc() != null) {
				updateJobDetails.setctc(jobDetails.getctc());
			} else {
				updateJobDetails.setctc(updateJobDetails.getctc());
			}
			if (jobDetails.getJobDescription() != null) {
				updateJobDetails.setJobDescription(jobDetails.getJobDescription());
			} else {
				updateJobDetails.setJobDescription(updateJobDetails.getJobDescription());
			}
			if (jobDetails.getSkillsRequired() != null) {
				updateJobDetails.setSkillsRequired(jobDetails.getSkillsRequired());
			} else {
				updateJobDetails.setSkillsRequired(updateJobDetails.getSkillsRequired());
			}
			if (jobDetails.getEligibilityCriteria() != null) {
				updateJobDetails.setEligibilityCriteria(jobDetails.getEligibilityCriteria());
			} else {
				updateJobDetails.setEligibilityCriteria(updateJobDetails.getEligibilityCriteria());
			}
			if (jobDetails.getContact() != null) {
				updateJobDetails.setContact(jobDetails.getContact());
			} else {
				updateJobDetails.setContact(updateJobDetails.getContact());
			}
			if (jobDetails.getApplyLink() != null) {
				updateJobDetails.setApplyLink(jobDetails.getApplyLink());
			} else {
				updateJobDetails.setApplyLink(updateJobDetails.getApplyLink());
			}
			if (jobDetails.getLastDate() != null) {
				updateJobDetails.setLastDate(jobDetails.getLastDate());
			} else {
				updateJobDetails.setLastDate(updateJobDetails.getLastDate());
			}
			if (jobDetails.getCreatedDate() != null) {
				updateJobDetails.setCreatedDate(jobDetails.getCreatedDate());
			} else {
				updateJobDetails.setCreatedDate(updateJobDetails.getCreatedDate());
			}
			if (jobDetails.getModifiedDate() != null) {
				updateJobDetails.setModifiedDate(jobDetails.getModifiedDate());
			} else {
				updateJobDetails.setModifiedDate(updateJobDetails.getModifiedDate());
			}
			if (jobDetails.getModifiedBy() != null) {
				updateJobDetails.setModifiedBy(jobDetails.getModifiedBy());
			} else {
				updateJobDetails.setModifiedBy(updateJobDetails.getModifiedBy());
			}
			if (jobDetails.getCreatedBy() != null) {
				updateJobDetails.setCreatedBy(jobDetails.getCreatedBy());
			} else {
				updateJobDetails.setCreatedBy(updateJobDetails.getCreatedBy());
			}

			try {
				JobDetails carrerManagemnetUpdateDetails = careerRepository.save(updateJobDetails);
				List<JobDetails> results = new ArrayList<>();
				results.add(carrerManagemnetUpdateDetails);
				careerManagementApiResponse.setResults(results);
				List<String> messages = new ArrayList<>();
				messages.add(" specific jobdetails field update successfully");
				Pagination pagination = new Pagination();
				pagination.setLimit(1);
				pagination.setOffset(0);
				pagination.setTotal(1);
				careerManagementApiResponse.setPagination(pagination);
				careerManagementApiResponse.setMessages(messages);
				careerManagementApiResponse.setStatusCode(200);
				careerManagementApiResponse.setStatusMessage("OK");

			} catch (Exception e) {
				throw new ResourceNotFoundException(
						"jobdetails with this " + jobId + " not available in Database or check enter information ");

			}

		} else {
			log.error("Couldn't process this request enter valid jobid");
			throw new ResourceNotFoundException("jobdetails  with this" + jobId + " not available in Database");

		}

		return careerManagementApiResponse;
	}

}
