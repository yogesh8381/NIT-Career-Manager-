package com.nabla.careermanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nabla.careermanagement.model.JobDetails;




/**
 * 
 * @author Yogesh
 *
 */
@Repository
public interface CareerRepository extends JpaRepository<JobDetails, Integer> {



	

}
