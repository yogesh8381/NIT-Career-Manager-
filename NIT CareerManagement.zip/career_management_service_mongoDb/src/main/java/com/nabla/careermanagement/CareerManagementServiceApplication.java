package com.nabla.careermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
/**
 * 
 * @author Yogesh
 *
 */
@EnableEurekaClient
@SpringBootApplication
public class CareerManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerManagementServiceApplication.class, args);
	}

}
