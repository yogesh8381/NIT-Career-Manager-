package com.nabla.careermanagement.service;

import javax.validation.Valid;

import com.nabla.careermanagement.model.CareerManagementApiResponse;
import com.nabla.careermanagement.model.JobDetails;

/**
 * @author Yogesh
 *
 */
public interface CareerManagementService {
	CareerManagementApiResponse addNewJobDetails(JobDetails jobdetails);

	/**
	 * this abstract method responsible  fetch all jobOpening
	 * @param offset
	 * @param limit
	 * @return jobOpening
	 */
	CareerManagementApiResponse getAllJobDetails(@Valid Integer offset, @Valid Integer limit);

	/**
	 * 
	 * @param jobId
	 * @return 
	 */

	CareerManagementApiResponse deletejobDetails(int jobId);

	/**
	 * 
	 * @param id
	 * @return  jobOpening
	 */

	CareerManagementApiResponse getjobOpeningById(int jobId);

	/**
	 * 
	 * @param jobId
	 * @param body
	 * @return jobOpening
	 */
	CareerManagementApiResponse updateJobDetailsSpecificField(Integer jobId, JobDetails jobdetails);

	/**
	 * 
	 * @param jobId
	 * @param body
	 * @return jobOpening
	 */
	CareerManagementApiResponse updateJobDetails(Integer jobId, JobDetails jobDetails);

}
