package com.nabla.careermanagement.fileupload.helper;

import java.io.File;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

/**
 * 
 * @author Yogesh
 *
 */
@Component
public class FileUploadHelper {
	public final String UPLOAD_DIR = new ClassPathResource("static/image/").getFile().getAbsolutePath();

	/**
	 * 
	 * @throws IOException
	 */
	public FileUploadHelper() throws IOException {

	}

	/**
	 * 
	 * @param multipartFile
	 * @return
	 */
	public boolean uploadFile(MultipartFile multipartFile) {
		boolean f = false;

		try {

			// //
			// InputStream is= multipartFile.getInputStream();
			// byte data[]=new byte[is.available()];
			// is.read(data);

			// //write
			// FileOutputStream fos=new
			// FileOutputStream(UPLOAD_DIR+File.separator+multipartFile.getOriginalFilename());
			// fos.write(data);

			// fos.flush();
			// fos.close();
			
			Files.copy(multipartFile.getInputStream(),
					Paths.get(UPLOAD_DIR + File.separator + multipartFile.getOriginalFilename()),
					StandardCopyOption.REPLACE_EXISTING);
			f = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

}

/*
 * public final String UPLOAD_DIR =
 * "C:\\Users\\hp\\Documents\\workspace-spring-tool-suite-4-4.9.0.RELEASE\\career_management_service\\src\\main\\resources\\static\\image";
 * 
 * public boolean uploadFile(MultipartFile multipartFile) throws IOException {
 * boolean f = false; Files.copy(multipartFile.getInputStream(),
 * Paths.get(UPLOAD_DIR + File.separator + multipartFile.getOriginalFilename()),
 * StandardCopyOption.REPLACE_EXISTING); return f; } }
 */