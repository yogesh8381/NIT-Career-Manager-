package com.careermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
